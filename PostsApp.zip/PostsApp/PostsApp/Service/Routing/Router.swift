//
//  Router.swift
//  PostsApp
//
//

import UIKit

protocol Router {
    
    func start()
}
