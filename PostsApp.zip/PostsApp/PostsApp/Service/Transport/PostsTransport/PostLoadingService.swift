//
//  PostsProvider.swift
//  PostsApp
//
//

import Foundation
import Moya

final class PostLoadingService {
    
    enum NetworkError: Error {
        case unknown
    }
    
    typealias PostsCompletion = (Result<[Post], NetworkError>) -> Void
    typealias PostsDTOCompletion = ([PostDTO]?) -> Void
    typealias UsersCompletion = ([UserDTO]?) -> Void
    typealias CommentsCompletion = ([CommentDTO]?) -> Void

    private let provider = MoyaProvider<PostsProvider>()
    private let jsonDecoder = JSONDecoder()
    
    func loadPosts(completion: @escaping PostsCompletion) {
        
        var posts = [Post]()
        
        var tempPosts = [PostDTO]()
        var tempUsers = [Int: UserDTO]()
        var tempComments = [Int: [CommentDTO]]()
        
        let dispatchGroup = DispatchGroup()
        dispatchGroup.enter()
        
        loadDTOPosts { dtoPosts in
            guard let dtoPosts = dtoPosts else {
                completion(.failure(.unknown))
                return
            }
            tempPosts = dtoPosts
            dispatchGroup.leave()
        }
        
        dispatchGroup.enter()
        loadUsers { users in
            guard let users = users else {
                completion(.failure(.unknown))
                return
            }
            tempUsers = Dictionary(uniqueKeysWithValues: users.map { ($0.id, $0) })
            dispatchGroup.leave()
        }
        
        dispatchGroup.enter()
        loadComments { comments in
            guard let comments = comments else {
                completion(.failure(.unknown))
                return
            }
            tempComments = Dictionary(grouping: comments, by: { $0.postId })
            dispatchGroup.leave()
        }
        
        dispatchGroup.notify(queue: .main) {
            posts = tempPosts.compactMap { (postDTO: PostDTO) -> Post? in
                guard let author = tempUsers[postDTO.userId],
                      let dtoComments = tempComments[postDTO.id]
                else { return nil }
                let comments = dtoComments.map { Comment(dto: $0) }
                return Post(id: postDTO.id, title: postDTO.title.capitalized, body: postDTO.body, author: author.name, comments: comments)
            }
            completion(.success(posts))
        }
    }
    
    private func loadDTOPosts(completion: @escaping PostsDTOCompletion) {
        provider.request(.posts) { [weak self] result in
            switch result {
                case let .success(response):
                    guard
                        let data = try? response.filterSuccessfulStatusCodes().data,
                        let posts = try? self?.jsonDecoder.decode([PostDTO].self, from: data)
                    else {
                        completion(nil)
                        return
                    }
                    completion(posts)
                case .failure:
                    completion(nil)
                }
        }
    }
    
    private func loadUsers(completion: @escaping UsersCompletion) {
        provider.request(.users) { [weak self] result in
            switch result {
                case let .success(response):
                    guard
                        let data = try? response.filterSuccessfulStatusCodes().data,
                        let users = try? self?.jsonDecoder.decode([UserDTO].self, from: data)
                    else {
                        completion(nil)
                        return
                    }
                    completion(users)
                case .failure:
                    completion(nil)
                }
        }
    }
    
    private func loadComments(completion: @escaping CommentsCompletion) {
        provider.request(.comments) { [weak self] result in
            switch result {
                case let .success(response):
                    guard
                        let data = try? response.filterSuccessfulStatusCodes().data,
                        let comments = try? self?.jsonDecoder.decode([CommentDTO].self, from: data)
                    else {
                        completion(nil)
                        return
                    }
                    completion(comments)
                case .failure:
                    completion(nil)
                }
        }
    }
}

