//
//  User.swift
//  PostsApp
//
//

import Foundation

struct UserDTO: Decodable {
    let id: Int
    let name: String
    let username: String
}
