//
//  Post.swift
//  PostsApp
//
//

import Foundation

struct PostDTO: Decodable {
    let id: Int
    let userId: Int
    let title: String
    let body: String
}
