//
//  Comment.swift
//  PostsApp
//
//

import Foundation

struct CommentDTO: Decodable {
    let id: Int
    let postId: Int
    let name: String
    let body: String
}
