//
//  PostsListViewController.swift
//  PostsApp
//
//

import UIKit

final class PostsListViewController: UIViewController {
    
    private enum Constants {
        static let title = "Posts for you"
        static let offset: CGFloat = 20
        static let titleFontSize: CGFloat = 40
    }
    
    var router: PostsRouter?
    
    private let service: PostLoadingService
    
    private var posts = [Post]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = Constants.title
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: Constants.titleFontSize, weight: .bold)
        return label
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = .systemGray6
        tableView.register(PostCell.self, forCellReuseIdentifier: PostCell.reuseIdentifier)
        return tableView
    }()
    
    init(service: PostLoadingService) {
        self.service = service
        super.init(nibName: nil, bundle: nil)
        makeConstraints()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startAnimating()
        service.loadPosts { [weak self] result in
            self?.stopAnimating()
            switch result {
            case let .success(posts):
                self?.posts = posts
            case .failure:
                self?.showError()
            }
        }
    }

    private func makeConstraints() {
        titleLabel.pin(to: [.trailing, .leading, .top], of: view, offset: Constants.offset, withSafeArea: true)
        tableView.pin(to: [.trailing, .leading, .bottom], of: view)
        tableView.topToBottom(of: titleLabel, offset: Constants.offset)
    }
    
}

extension PostsListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard
            let post = posts[safe: indexPath.row],
            let cell = tableView.dequeueReusableCell(withIdentifier: PostCell.reuseIdentifier, for: indexPath) as? PostCell else {
            return UITableViewCell()
        }
        cell.configure(viewModel: PostListViewModel(post: post))
        return cell
    }
}

extension PostsListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let post = posts[safe: indexPath.row] else { return }
        router?.showDetail(post: post)
    }
}

extension PostsListViewController: AlertShowable, LoaderShowable {}
