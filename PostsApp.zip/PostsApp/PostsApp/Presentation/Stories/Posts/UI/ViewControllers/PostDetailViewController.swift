//
//  PostDetailViewController.swift
//  PostsApp
//
//

import UIKit

final class PostDetailViewController: UIViewController {
    
    private enum Section: Int, CaseIterable {
        case post
        case comments
    }
    
    private let post: Post
    private let comments: [Comment]
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .insetGrouped)
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = .systemGray6
        tableView.register(PostDetailCell.self, forCellReuseIdentifier: PostDetailCell.reuseIdentifier)
        tableView.register(CommentCell.self, forCellReuseIdentifier: CommentCell.reuseIdentifier)
        return tableView
    }()
    
    private func makeConstraints() {
        tableView.pinToEdges(of: view)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    init(post: Post) {
        self.post = post
        self.comments = post.comments
        super.init(nibName: nil, bundle: nil)
        makeConstraints()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

extension PostDetailViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return Section.allCases.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == Section.post.rawValue ? 1 : comments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = Section(rawValue: indexPath.section)
        switch section {
        case .post:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: PostDetailCell.reuseIdentifier, for: indexPath) as? PostDetailCell else {
                return UITableViewCell()
            }
            cell.configure(post: post)
            return cell
        case .comments:
            guard
                let comment = comments[safe: indexPath.row],
                let cell = tableView.dequeueReusableCell(withIdentifier: CommentCell.reuseIdentifier, for: indexPath) as? CommentCell else {
                return UITableViewCell()
            }
            cell.configure(comment: comment)
            return cell
        default: return UITableViewCell()
        }
    }
}
