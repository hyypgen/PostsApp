//
//  CommentCell.swift
//  PostsApp
//
//

import UIKit
final class CommentCell: UITableViewCell {
    
    private enum Constants {
        static let offset: CGFloat = 20
        static let spacing: CGFloat = 8
        static let defaultFontSize: CGFloat = 15
        static let titleFontSize: CGFloat = 20
    }
    
    private lazy var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = Constants.spacing
        return stackView
    }()
    
    private lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: Constants.titleFontSize, weight: .semibold)
        return label
    }()
    
    private lazy var bodyLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: Constants.defaultFontSize, weight: .regular)
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .systemGray6
        makeConstraints()
        setupStackView()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func configure(comment: Comment) {
        nameLabel.text = comment.name
        bodyLabel.text = comment.body
    }
    
    private func makeConstraints() {
        stackView.pin(to: [.leading], of: self, offset: Constants.offset * 2)
        stackView.pin(to: [.top, .bottom, .trailing], of: self, offset: Constants.offset)
    }
    
    private func setupStackView() {
        [nameLabel, bodyLabel].forEach {
            stackView.addArrangedSubview($0)
        }
    }
}
