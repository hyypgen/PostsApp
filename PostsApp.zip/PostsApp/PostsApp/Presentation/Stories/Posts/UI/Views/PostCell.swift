//
//  PostCell.swift
//  PostsApp
//
//

import UIKit

final class PostCell: UITableViewCell {
    
    private enum Constants {
        static let offset: CGFloat = 12
        static let spacing: CGFloat = 8
        static let defaultFontSize: CGFloat = 15
        static let titleFontSize: CGFloat = 20
        static let cornerRadius: CGFloat = 20
    }
    
    private lazy var containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = Constants.cornerRadius
        return view
    }()
    
    private lazy var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = Constants.spacing
        return stackView
    }()
    
    private lazy var headingLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemBlue
        label.font = .systemFont(ofSize: Constants.defaultFontSize, weight: .semibold)
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: Constants.titleFontSize, weight: .semibold)
        return label
    }()
    
    private lazy var authorCommentsLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemGray
        label.font = .systemFont(ofSize: Constants.defaultFontSize, weight: .regular)
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .systemGray6
        selectionStyle = .none
        makeConstraints()
        setupStackView()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func configure(viewModel: PostListViewModel) {
        titleLabel.text = viewModel.title
        headingLabel.text = viewModel.heading
        authorCommentsLabel.text = viewModel.authorCommentsText
    }
    
    private func makeConstraints() {
        containerView.pinToEdges(of: self, offset: Constants.offset * 1.5)
        stackView.pinToEdges(of: containerView, offset: Constants.offset)
    }
    
    private func setupStackView() {
        [headingLabel, titleLabel, authorCommentsLabel].forEach {
            stackView.addArrangedSubview($0)
        }
    }
}
