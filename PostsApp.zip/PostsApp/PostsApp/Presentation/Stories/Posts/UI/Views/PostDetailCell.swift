//
//  PostDetailCell.swift
//  PostsApp
//
//

import UIKit

final class PostDetailCell: UITableViewCell {
    
    private enum Constants {
        static let offset: CGFloat = 20
        static let spacing: CGFloat = 20
        static let defaultFontSize: CGFloat = 15
        static let titleFontSize: CGFloat = 20
        static let bigFontSize: CGFloat = 40
    }
    
    private lazy var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = Constants.spacing
        return stackView
    }()
    
    private lazy var headingLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemBlue
        label.font = .systemFont(ofSize: Constants.defaultFontSize, weight: .semibold)
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: Constants.bigFontSize, weight: .bold)
        return label
    }()
    
    private lazy var bodyLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: Constants.titleFontSize, weight: .regular)
        return label
    }()
    
    private lazy var authorLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemGray
        label.font = .systemFont(ofSize: Constants.defaultFontSize, weight: .regular)
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        makeConstraints()
        setupStackView()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func configure(post: Post) {
        headingLabel.text = post.heading.uppercased()
        titleLabel.text = post.title
        authorLabel.text = post.author
        bodyLabel.text = post.body
    }
    
    private func makeConstraints() {
        stackView.pinToEdges(of: self, offset: Constants.offset)
    }
    
    private func setupStackView() {
        [headingLabel, titleLabel, authorLabel, bodyLabel].forEach {
            stackView.addArrangedSubview($0)
        }
    }
}
