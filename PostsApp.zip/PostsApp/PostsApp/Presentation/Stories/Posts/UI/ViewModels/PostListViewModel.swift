//
//  PostListViewModel.swift
//  PostsApp
//
//

import Foundation

struct PostListViewModel {
    let heading: String
    let title: String
    let authorCommentsText: String
}

extension PostListViewModel {
    
    init(post: Post) {
        heading = post.heading
        title = post.title
        authorCommentsText = "\(post.author) • \(post.comments.count) comments"
    }
}
