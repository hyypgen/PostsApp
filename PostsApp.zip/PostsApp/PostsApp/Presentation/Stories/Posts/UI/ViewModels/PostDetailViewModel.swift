//
//  PostDetailViewModel.swift
//  PostsApp
//
//

import Foundation

struct PostDetailViewModel {
    let heading: String
    let title: String
    let body: String
    let author: String
    let comments: [Comment]
}
