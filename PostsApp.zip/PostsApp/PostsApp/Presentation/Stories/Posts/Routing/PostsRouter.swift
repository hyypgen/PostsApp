//
//  PostsRouter.swift
//  PostsApp
//
//

import UIKit

final class PostsRouter: Router {
    
    private let navigationController: UINavigationController
    private let factory: PostsRouterFactory
    
    init(navigationController: UINavigationController, factory: PostsRouterFactory) {
        self.navigationController = navigationController
        self.factory = factory
        setupNavigationBar()
    }
    
    func start() {
        let postsListViewController = factory.makePostsList()
        postsListViewController.router = self
        navigationController.setNavigationBarHidden(true, animated: false)
        navigationController.setViewControllers([postsListViewController], animated: true)
    }
    
    func showDetail(post: Post) {
        let postDetailViewController = factory.makePostDetail(post: post)
        setupBackTitle()
        navigationController.setNavigationBarHidden(false, animated: false)
        navigationController.pushViewController(postDetailViewController, animated: true)
    }
    
    private func setupNavigationBar() {
        let translucentImage = UIImage()
        navigationController.navigationBar.shadowImage = translucentImage
        navigationController.navigationBar.tintColor = .black
        navigationController.navigationBar.backgroundColor = .systemGray6
    }
    
    private func setupBackTitle() {
        navigationController.topViewController?.navigationItem.title = ""
    }
}
