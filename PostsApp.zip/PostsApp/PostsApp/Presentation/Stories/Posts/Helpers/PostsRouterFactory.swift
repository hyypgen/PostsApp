//
//  PostsRouterFactory.swift
//  PostsApp
//

import Foundation

struct PostsRouterFactory {
    
    private let service: PostLoadingService
    
    init(service: PostLoadingService) {
        self.service = service
    }
    
    func makePostsList() -> PostsListViewController {
        let postsListViewController = PostsListViewController(service: service)
        return postsListViewController
    }
    
    func makePostDetail(post: Post) -> PostDetailViewController {
        let postDetailViewController = PostDetailViewController(post: post)
        return postDetailViewController
    }
}
