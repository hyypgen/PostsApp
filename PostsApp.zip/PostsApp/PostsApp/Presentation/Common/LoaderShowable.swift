//
//  LoaderShowable.swift
//  PostsApp
//
//

import NVActivityIndicatorView
import UIKit

protocol LoaderShowable: AnyObject {

}

extension LoaderShowable {

    var loaderDefaultSettings: ActivityData {
        return ActivityData(type: .ballPulse,
                            color: .systemGray,
                            minimumDisplayTime: 100,
                            backgroundColor: UIColor.systemGray.withAlphaComponent(0.3))
    }

    func startAnimating() {
        animate()
    }

    func stopAnimating() {
        NVActivityIndicatorPresenter.sharedInstance.stopAnimating(NVActivityIndicatorView.DEFAULT_FADE_OUT_ANIMATION)
    }

    private func animate() {
        NVActivityIndicatorPresenter.sharedInstance.startAnimating(loaderDefaultSettings, NVActivityIndicatorView.DEFAULT_FADE_IN_ANIMATION)
    }
}

extension LoaderShowable where Self: UIViewController {

    func startAnimating(_ shouldHideKeyboard: Bool = true) {
        if shouldHideKeyboard {
            view.endEditing(true)
        }

        animate()
    }

}
