import UIKit

enum Edge {
    case top, bottom, leading, trailing
}

enum Axis {
    case x, y
}

extension UIView {

    func add(to parentView: UIView, insets: UIEdgeInsets = .zero) {
        translatesAutoresizingMaskIntoConstraints = false
        parentView.addSubview(self)
        NSLayoutConstraint.activate([
            topAnchor.constraint(equalTo: parentView.topAnchor, constant: insets.top),
            bottomAnchor.constraint(equalTo: parentView.bottomAnchor, constant: -insets.bottom),
            trailingAnchor.constraint(equalTo: parentView.trailingAnchor, constant: -insets.right),
            leadingAnchor.constraint(equalTo: parentView.leadingAnchor, constant: insets.left)
        ])
    }

    func add(to parentView: UIView, offset: CGFloat) {
        translatesAutoresizingMaskIntoConstraints = false
        parentView.addSubview(self)
        NSLayoutConstraint.activate([
            topAnchor.constraint(equalTo: parentView.topAnchor, constant: offset),
            bottomAnchor.constraint(equalTo: parentView.bottomAnchor, constant: -offset),
            trailingAnchor.constraint(equalTo: parentView.trailingAnchor, constant: -offset),
            leadingAnchor.constraint(equalTo: parentView.leadingAnchor, constant: offset)
        ])
    }

    func pinToEdges(of parentView: UIView, offset: CGFloat = 0) {
        translatesAutoresizingMaskIntoConstraints = false
        addAsSubviewAsNeeded(toView: parentView)
        NSLayoutConstraint.activate([
            topAnchor.constraint(equalTo: parentView.topAnchor, constant: offset),
            bottomAnchor.constraint(equalTo: parentView.bottomAnchor, constant: -offset),
            trailingAnchor.constraint(equalTo: parentView.trailingAnchor, constant: -offset),
            leadingAnchor.constraint(equalTo: parentView.leadingAnchor, constant: offset)
        ])
    }

    func pin(to edges: [Edge], of parentView: UIView, offset: CGFloat = 0, withSafeArea: Bool = false) {
        translatesAutoresizingMaskIntoConstraints = false
        addAsSubviewAsNeeded(toView: parentView)

        var constraints = [NSLayoutConstraint]()
        if edges.contains(.top) {
            let anchor = withSafeArea ?
                parentView.safeAreaLayoutGuide.topAnchor :
                parentView.topAnchor

            constraints.append(
                topAnchor.constraint(equalTo: anchor, constant: offset)
            )
        }
        if edges.contains(.bottom) {
            let anchor = withSafeArea ?
                parentView.safeAreaLayoutGuide.bottomAnchor :
                parentView.bottomAnchor

            constraints.append(
                bottomAnchor.constraint(equalTo: anchor, constant: -offset)
            )
        }
        if edges.contains(.leading) {
            let anchor = withSafeArea ?
                parentView.safeAreaLayoutGuide.leadingAnchor :
                parentView.leadingAnchor
            constraints.append(
                leadingAnchor.constraint(equalTo: anchor, constant: offset)
            )
        }
        if edges.contains(.trailing) {
            let anchor = withSafeArea ?
                parentView.safeAreaLayoutGuide.trailingAnchor :
                parentView.trailingAnchor
            constraints.append(
                trailingAnchor.constraint(equalTo: anchor, constant: -offset)
            )
        }
        NSLayoutConstraint.activate(constraints)
    }

    func topToBottom(of view: UIView, offset: CGFloat = 0) {
        translatesAutoresizingMaskIntoConstraints = false
        topAnchor.constraint(equalTo: view.bottomAnchor, constant: offset).isActive = true
    }

    func bottomToTop(of view: UIView, offset: CGFloat = 0) {
        translatesAutoresizingMaskIntoConstraints = false
        bottomAnchor.constraint(equalTo: view.topAnchor, constant: -offset).isActive = true
    }

    func leftToRight(of view: UIView, offset: CGFloat = 0) {
        translatesAutoresizingMaskIntoConstraints = false
        leadingAnchor.constraint(equalTo: view.trailingAnchor, constant: offset).isActive = true
    }

    func rightToLeft(of view: UIView, offset: CGFloat = 0) {
        translatesAutoresizingMaskIntoConstraints = false
        trailingAnchor.constraint(equalTo: view.leadingAnchor, constant: offset).isActive = true
    }

    func addToCenter(of parentView: UIView, excluding axes: [Axis] = [], xOffset: CGFloat = 0, yOffset: CGFloat = 0) {
        translatesAutoresizingMaskIntoConstraints = false
        addAsSubviewAsNeeded(toView: parentView)
        var constraints = [NSLayoutConstraint]()
        if axes.contains(.x) {
            constraints = [
                centerYAnchor.constraint(equalTo: parentView.centerYAnchor, constant: yOffset)
            ]
        } else if axes.contains(.y) {
            constraints = [
                centerXAnchor.constraint(equalTo: parentView.centerXAnchor, constant: xOffset)
            ]
        } else {
            constraints = [
                centerXAnchor.constraint(equalTo: parentView.centerXAnchor, constant: xOffset),
                centerYAnchor.constraint(equalTo: parentView.centerYAnchor, constant: yOffset)
            ]
        }
        NSLayoutConstraint.activate(constraints)
    }

    func addToCenter(of parentView: UIView) {
        translatesAutoresizingMaskIntoConstraints = false
        addAsSubviewAsNeeded(toView: parentView)
        let constraints = [
            centerXAnchor.constraint(equalTo: parentView.centerXAnchor),
            centerYAnchor.constraint(equalTo: parentView.centerYAnchor)
        ]
        NSLayoutConstraint.activate(constraints)
    }

    func setSize(width: CGFloat, height: CGFloat) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalToConstant: width),
            heightAnchor.constraint(equalToConstant: height)
        ])
    }

    func setWidth(_ width: CGFloat) {
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalToConstant: width)
        ])
    }

    @discardableResult
    func setHeight(_ height: CGFloat) -> NSLayoutConstraint {
        translatesAutoresizingMaskIntoConstraints = false
        let constraint = heightAnchor.constraint(equalToConstant: height)
        constraint.isActive = true
        return constraint
    }

    private func addAsSubviewAsNeeded(toView: UIView) {
        if toView != self.superview {
            toView.addSubview(self)
        }
    }

}
