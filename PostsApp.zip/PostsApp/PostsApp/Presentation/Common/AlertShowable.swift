//
//  AlertShowable.swift
//  PostsApp
//
//

import SPAlert
import UIKit

protocol AlertShowable: AnyObject {
    func showError(text: String)
}

extension AlertShowable where Self: UIViewController {
    
    func showError(text: String = "Network error") {
        SPAlert.present(title: text, preset: .error)
    }
}
