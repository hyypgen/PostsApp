//
//  PostComment.swift
//  PostsApp
//
//

import Foundation

struct Comment {
    let name: String
    let body: String
}

extension Comment {
    
    init(dto: CommentDTO) {
        self.name = dto.name.capitalized
        self.body = dto.body
    }
}
