//
//  Post.swift
//  PostsApp
//
//

import Foundation

struct Post {
    let id: Int
    let title: String
    let body: String
    let author: String
    let comments: [Comment]
    let heading = Post.randomHeading()
}

extension Post {
    
    static func randomHeading() -> String {
        let headings = ["Design", "Sports", "Fashion", "Tech"]
        return headings.randomElement()?.uppercased() ?? "Design"
    }
}
